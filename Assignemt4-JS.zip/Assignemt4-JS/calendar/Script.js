let currentYear, currentMonth;
function renderCalendar(year, month) {
  const daysContainer = document.getElementById("days");
  const monthYear = document.getElementById("month-year");
  const now = new Date();
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  monthYear.textContent = `${monthNames[month]} ${year}`;
  const firstDay = new Date(year, month, 1).getDay();
  const totalDays = new Date(year, month + 1, 0).getDate();
  daysContainer.innerHTML = "";
  for (let i = 0; i < firstDay; i++) {
    const blankDay = document.createElement("div");
    daysContainer.appendChild(blankDay);
  }
  for (let day = 1; day <= totalDays; day++) {
    const dayElement = document.createElement("div");
    dayElement.classList.add("day");
    dayElement.textContent = day;
    if (
      year === now.getFullYear() &&
      month === now.getMonth() &&
      day === now.getDate()
    ) {
      dayElement.classList.add("current");
    }

    daysContainer.appendChild(dayElement);
  }
}
function prevMonth() {
  currentMonth--;
  if (currentMonth < 0) {
    currentMonth = 11;
    currentYear--;
  }
  renderCalendar(currentYear, currentMonth);
}
function nextMonth() {
  currentMonth++;
  if (currentMonth > 11) {
    currentMonth = 0;
    currentYear++;
  }
  renderCalendar(currentYear, currentMonth);
}
function initCalendar() {
  const now = new Date();
  currentYear = now.getFullYear();
  currentMonth = now.getMonth();

  renderCalendar(currentYear, currentMonth);

  document.getElementById("prev-btn").addEventListener("click", prevMonth);
  document.getElementById("next-btn").addEventListener("click", nextMonth);
}
initCalendar();
