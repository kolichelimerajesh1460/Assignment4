const text = [
    "Welcome to the Typewriter Animation",
    "This is  Basic TypeWriter Example.",
  ];
  
  let currentTextIndex = 0;
  let currentCharIndex = 0;
  const typingSpeed = 100; 
  const pauseBetweenTexts = 1500; 
  const typewriterElement = document.getElementById("typewriter-text");
  
  function typewriter() {
    const currentText = text[currentTextIndex];
    typewriterElement.textContent = currentText.substring(0, currentCharIndex);
  
    if (currentCharIndex < currentText.length) {
      currentCharIndex++;
      setTimeout(typewriter, typingSpeed);
    } else {
      setTimeout(() => {
        currentCharIndex = 0;
        currentTextIndex = (currentTextIndex + 1) % text.length; 
        typewriter();
      }, pauseBetweenTexts);
    }
  }
  typewriter();
  