let slideIndex = 0;
let slideInterval;
function showSlide(index) {
  const slides = document.getElementsByClassName("slide");
  if (index >= slides.length) {
    slideIndex = 0;
  } else if (index < 0) {
    slideIndex = slides.length - 1;
  }
  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slides[slideIndex].style.display = "block";
}
function nextSlide() {
  slideIndex++;
  showSlide(slideIndex);
}
function prevSlide() {
  slideIndex--;
  showSlide(slideIndex);
}
function startSlideshow() {
  slideInterval = setInterval(() => {
    nextSlide();
  }, 3000);
}
function stopSlideshow() {
  clearInterval(slideInterval);
}
document.getElementById("next-btn").addEventListener("click", () => {
  stopSlideshow(); 
  nextSlide();
  startSlideshow(); 
});
document.getElementById("prev-btn").addEventListener("click", () => {
  stopSlideshow(); 
  prevSlide();
  startSlideshow(); 
});
showSlide(slideIndex);
startSlideshow();
